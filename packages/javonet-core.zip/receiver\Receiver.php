<?php

declare(strict_types=1);

namespace core\receiver;

use core\interpreter\Interpreter;
use core\protocol\CommandSerializer;
use utils\connectiondata\IConnectionData;
use utils\connectiondata\InMemoryConnectionData;
use utils\RuntimeLogger;

final class Receiver
{
    private IConnectionData $connectionData;

    public function __construct()
    {
        $this->connectionData = new InMemoryConnectionData();
    }

    public function sendCommand(array $messageByteArray): array
    {
        return CommandSerializer::serialize((new Interpreter())->process($messageByteArray), $this->connectionData);
    }

    public function heartBeat(array $messageByteArray): array
    {
        return [$messageByteArray[11], $messageByteArray[12] - 2];
    }

    public function getRuntimeInfo(): string
    {
        return RuntimeLogger::getRuntimeInfo();
    }
}
