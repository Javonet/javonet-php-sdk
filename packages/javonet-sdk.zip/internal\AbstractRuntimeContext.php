<?php

declare(strict_types=1);

namespace sdk\internal;

interface AbstractRuntimeContext
{
    public function execute(): void;
}
