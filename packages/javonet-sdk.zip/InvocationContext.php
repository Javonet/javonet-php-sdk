<?php

declare(strict_types=1);

namespace sdk;

use ArrayAccess;
use core\delegatecache\DelegatesCache;
use core\interpreter\Interpreter;
use ReflectionMethod;
use ReflectionNamedType;
use ReflectionType;
use RuntimeException;
use sdk\internal\AbstractArrayContext;
use sdk\internal\AbstractEnumContext;
use sdk\internal\AbstractEventContext;
use sdk\internal\AbstractInstanceContext;
use sdk\internal\AbstractInvocationContext;
use sdk\internal\AbstractStaticContext;
use sdk\internal\InvocationContextIterator;
use TypeError;
use utils\Command;
use utils\CommandInterface;
use utils\connectiondata\IConnectionData;
use utils\error\UnsupportedPayloadItemTypeError;
use utils\exception\ExceptionThrower;
use utils\exception\UnsupportedOperationException;
use utils\RuntimeName;
use utils\type\CommandType;
use utils\TypesHandler;
use IteratorAggregate;

final class InvocationContext implements AbstractInvocationContext, AbstractInstanceContext, AbstractStaticContext, AbstractArrayContext, AbstractEnumContext, AbstractEventContext, IteratorAggregate, ArrayAccess
{
    private Interpreter $interpreter;
    private RuntimeName $runtimeName;
    private CommandInterface $currentCommand;

    /** @var mixed */
    private $resultValue;
    private bool $isExecuted;
    private IConnectionData $connectionData;

    public function __construct(
        RuntimeName $runtime,
        IConnectionData $connectionData,
        CommandInterface $command,
        bool $isExecuted = false
    ) {
        $this->runtimeName = $runtime;
        $this->connectionData = $connectionData;
        $this->currentCommand = $command;
        $this->isExecuted = $isExecuted;
        $this->interpreter = new Interpreter();
    }

    public function getIterator(): InvocationContextIterator
    {
        if ($this->currentCommand->getCommandType()->notEqualsByValue(CommandType::REFERENCE)) {
            throw new RuntimeException('Object is not iterable');
        }

        return new InvocationContextIterator($this);
    }

    public function execute(): InvocationContext
    {
        $responseCommand = $this->interpreter->execute($this->currentCommand, $this->connectionData);
        if ($responseCommand->getCommandType()->equalsByValue(CommandType::EXCEPTION)) {
            ExceptionThrower::throwException($responseCommand);
        }

        if ($responseCommand->getCommandType()->equalsByValue(CommandType::CREATE_INSTANCE)) {
            $this->currentCommand = $responseCommand;
            $this->isExecuted = true;
            return $this;
        }

        return new InvocationContext($this->runtimeName, $this->connectionData, $responseCommand, true);
    }

    public function getInstanceField(string $fieldName): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_FIELD(), $fieldName);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setInstanceField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_INSTANCE_FIELD(), $fieldName, $value);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function invokeInstanceMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_INSTANCE_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function createInstance(...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_INSTANCE(), ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function invokeGenericMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getRefValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_REF_VALUE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function createNull(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::CREATE_NULL());
        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    private function buildCommand(CommandInterface $command): CommandInterface
    {
        foreach ($command->getPayload() as $key => $item) {
            $command->setPayload($key, $this->encapsulatePayloadItem($item));
        }

        return $command->prependArgumentToPayload($this->currentCommand);
    }

    /**
     * @param mixed $payloadItem
     */
    private function encapsulatePayloadItem($payloadItem): CommandInterface
    {
        if ($payloadItem === null) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof CommandInterface) {
            foreach ($payloadItem->getPayload() as $key => $item) {
                $payloadItem->setPayload($key, $this->encapsulatePayloadItem($item));
            }

            return $payloadItem;
        }

        if ($payloadItem instanceof InvocationContext) {
            return $payloadItem->getCurrentCommand();
        }

        if ($payloadItem instanceof ReflectionType) {
            return new Command($this->runtimeName, CommandType::CONVERT_TYPE(), TypesHandler::convertTypeToJavonetType($payloadItem));
        }

        if (is_array($payloadItem)) {
            $encapsulatedArray = [];
            foreach ($payloadItem as $item) {
                $encapsulatedArray[] = $this->encapsulatePayloadItem($item);
            }
            return new Command($this->runtimeName, CommandType::ARRAY(), $encapsulatedArray);
        }

        if (TypesHandler::isSimpleType($payloadItem)) {
            return new Command($this->runtimeName, CommandType::VALUE(), $payloadItem);
        }

        if ($payloadItem instanceof ReflectionMethod) {
            $types = [];
            foreach ($payloadItem->getParameters() as $param) {
                $type = $param->getType();
                if ($type instanceof ReflectionNamedType) {
                    $typeName = $type->getName();
                    if ($type->isBuiltin()) {
                        $types[] = $typeName;
                    } else {
                        $types[] = ($typeName[0] === '\\' ? '' : '\\') . $typeName;
                    }
                } else {
                    $types[] = 'mixed';
                }
            }

            $returnType = $payloadItem->getReturnType();
            if ($returnType instanceof ReflectionNamedType) {
                $returnTypeName = $returnType->getName();
                if ($returnType->isBuiltin()) {
                    $types[] = $returnTypeName;
                } else {
                    $types[] = ($returnTypeName[0] === '\\' ? '' : '\\') . $returnTypeName;
                }
            } else {
                $types[] = 'mixed';
            }

            $delegateId = DelegatesCache::getInstance()->addDelegate($payloadItem);
            $args = array_merge([$delegateId, RuntimeName::PHP], $types);

            $encapsulatedArgs = [];
            foreach ($args as $arg) {
                $encapsulatedArgs[] = $this->encapsulatePayloadItem($arg);
            }

            return new Command($this->runtimeName, CommandType::PASS_DELEGATE(), $encapsulatedArgs);
        }

        throw new UnsupportedPayloadItemTypeError($payloadItem);
    }

    public function getInstanceMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_INSTANCE_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData,
            $this->buildCommand($localCommand));
    }
    public function invokeStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_STATIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getStaticField(string $fieldName): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_FIELD(), $fieldName);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setStaticField(string $fieldName, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::SET_STATIC_FIELD(), $fieldName, $value);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function invokeGenericStaticMethod(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::INVOKE_GENERIC_STATIC_METHOD(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getStaticMethodAsDelegate(string $methodName, ...$args): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_STATIC_METHOD_AS_DELEGATE(), $methodName, ...$args);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getSize(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_SIZE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getRank(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_RANK());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getIndex(...$indexes): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_GET_ITEM(), ...$indexes);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function setIndex($indexes, $value): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ARRAY_SET_ITEM(), $indexes, $value);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getEnumName(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_NAME());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getEnumValue(): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::GET_ENUM_VALUE());

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function addEventListener(string $eventName, $eventHandler): InvocationContext
    {
        $localCommand = new Command($this->runtimeName, CommandType::ADD_EVENT_LISTENER(), $eventName, $eventHandler);

        return new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
    }

    public function getCurrentCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    public function getCommand(): CommandInterface
    {
        return $this->currentCommand;
    }

    /**
     * @return mixed
     */
    public function getValue()
    {
        $this->resultValue = $this->currentCommand->getPayload()[0];

        return $this->resultValue;
    }

    public function retrieveArray(): array
    {
        $localCommand = new Command($this->runtimeName, CommandType::RETRIEVE_ARRAY());
        $localInvCtx = new InvocationContext($this->runtimeName, $this->connectionData, $this->buildCommand($localCommand));
        $arrayInvCtx = $localInvCtx->execute();

        return $arrayInvCtx->currentCommand->getPayload();
    }

    /**
     * @param $offset mixed
     */
    public function offsetExists($offset): bool
    {
        return is_int($offset) && $offset >= 0;
    }

    /**
     * @param $offset mixed
     */
    public function offsetGet($offset): InvocationContext
    {
        return $this->getIndex($offset);
    }

    /**
     * @param mixed $offset
     * @param mixed $value
     */
    public function offsetSet($offset, $value): void
    {
        $this->setIndex($offset, $value)->execute();
    }

    /**
     * @param $offset mixed
     */
    public function offsetUnset($offset): void
    {
        throw new UnsupportedOperationException('Unsetting array elements via ArrayAccess is not supported.');
    }
}
