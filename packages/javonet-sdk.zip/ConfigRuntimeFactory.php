<?php

declare(strict_types=1);

namespace sdk;

use Exception;
use RuntimeException;
use sdk\internal\AbstractConfigRuntimeFactory;
use sdk\tools\JsonResolver;
use Throwable;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\TcpConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\RuntimeName;
use utils\RuntimeNameHandler;
use utils\UtilsConst;

final class ConfigRuntimeFactory implements AbstractConfigRuntimeFactory
{
    private string $configSource;

    public function __construct(string $configSource)
    {
        $this->configSource = $configSource;
    }

    public function clr(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::CLR(), $configName);
    }

    public function jvm(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::JVM(), $configName);
    }

    public function netcore(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::NETCORE(), $configName);
    }

    public function perl(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::PERL(), $configName);
    }

    public function python(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::PYTHON(), $configName);
    }

    public function ruby(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::RUBY(), $configName);
    }

    public function nodejs(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::NODEJS(), $configName);
    }

    /**
     * @throws Throwable
     */
    public function python27(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::PYTHON27(), $configName);
    }

    public function php(string $configName): RuntimeContext
    {
        return $this->getRuntimeContext(RuntimeName::PHP(), $configName);
    }

    /**
     * @throws Throwable
     */
    private function getRuntimeContext(RuntimeName $runtime, string $configName): RuntimeContext
    {
        $jsonResolver = new JsonResolver($this->configSource);

        try {
            UtilsConst::setLicenseKey($jsonResolver->getLicenseKey());
        } catch (Exception $e) {
        }

        try {
            UtilsConst::setJavonetWorkingDirectory($jsonResolver->getWorkingDirectory());
        } catch (Exception $e) {
        }

        $connType = $jsonResolver->getChannelType(RuntimeNameHandler::getName($runtime), $configName);
        $connData = null;
        if ('inMemory' === $connType) {
            $connData = new InMemoryConnectionData();
        } else if ('tcp' === $connType) {
            try {
                $connData = new TcpConnectionData(
                    $jsonResolver->getChannelHost(RuntimeNameHandler::getName($runtime), $configName),
                    $jsonResolver->getChannelPort(RuntimeNameHandler::getName($runtime), $configName)
                );
            } catch (Exception $e) {
                throw new RuntimeException($e);
            }
        } else if ('webSocket' === $connType) {
            $connData = new WsConnectionData($jsonResolver->getChannelHost(RuntimeNameHandler::getName($runtime), $configName));
        } else {
            throw new RuntimeException('Invalid connection type');
        }

        $rtmCtx = RuntimeContext::getInstance($runtime, $connData);
        $this->loadModules($runtime, $configName, $jsonResolver, $rtmCtx);

        return $rtmCtx;
    }

    /**
     * @throws Throwable
     */
    private function loadModules($runtime, string $configName, JsonResolver $jfr, RuntimeContext $rtmCtx): void
    {
        $modules = explode(',', $jfr->getModules(RuntimeNameHandler::getName($runtime), $configName));

        $configFileRealPath = realpath($this->configSource);
        $configDirectoryAbsolutePath = $configFileRealPath ? dirname($configFileRealPath) : null;

        if ($configDirectoryAbsolutePath === null) {
            return;
        }

        foreach ($modules as $module)
        {
            $trimmedModule = trim($module);
            if (!empty($trimmedModule)) {
                $isAbsolute = substr($trimmedModule, 0, 1) === '/' || substr($trimmedModule, 0, 1) === '\\' || preg_match('~^[A-Z]:[\\\\/]~i', $trimmedModule);
                if ($isAbsolute) {
                    $rtmCtx->loadLibrary($trimmedModule);
                } else {
                    $rtmCtx->loadLibrary($configDirectoryAbsolutePath . DIRECTORY_SEPARATOR . $trimmedModule);
                }
            }
        }
    }
}
