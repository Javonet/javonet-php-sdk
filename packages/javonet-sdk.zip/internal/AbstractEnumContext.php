<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\InvocationContext;

interface AbstractEnumContext
{
    public function getEnumName(): InvocationContext;
    public function getEnumValue(): InvocationContext;
}
