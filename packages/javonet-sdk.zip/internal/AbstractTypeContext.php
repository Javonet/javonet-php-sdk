<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\InvocationContext;

interface AbstractTypeContext
{
    public function getType(string $typeName, ...$args): InvocationContext;
}
