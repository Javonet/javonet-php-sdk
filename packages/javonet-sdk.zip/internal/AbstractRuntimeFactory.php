<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\RuntimeContext;

interface AbstractRuntimeFactory
{
    public function clr(): RuntimeContext;
    public function jvm(): RuntimeContext;
    public function netcore(): RuntimeContext;
    public function perl(): RuntimeContext;
    public function python(): RuntimeContext;
    public function ruby(): RuntimeContext;
    public function nodejs(): RuntimeContext;
    public function python27(): RuntimeContext;
    public function php(): RuntimeContext;
}