<?php

declare(strict_types=1);

namespace sdk\internal;

use Iterator;
use sdk\InvocationContext;

final class InvocationContextIterator implements Iterator
{
    private int $position;
    private int $arraySize;
    private ?InvocationContext $currentElement = null;
    private InvocationContext $arrayAsInvocationContext;

    public function __construct(InvocationContext $arrayAsInvocationContext)
    {
        $this->arrayAsInvocationContext = $arrayAsInvocationContext;
        $this->position = -1;
        $this->arraySize = (int)$this->arrayAsInvocationContext->getSize()->execute()->getValue();
    }

    public function current(): ?InvocationContext
    {
        return $this->currentElement;
    }

    public function key(): int
    {
        return $this->position;
    }

    public function next(): void
    {
        $this->position++;
        if ($this->valid()) {
            $this->currentElement = $this->arrayAsInvocationContext->getIndex($this->position)->execute();
        } else {
            $this->currentElement = null;
        }
    }

    public function rewind(): void
    {
        $this->position = -1;
        $this->next();
    }

    public function valid(): bool
    {
        return $this->position >= 0 && $this->position < $this->arraySize;
    }
}
