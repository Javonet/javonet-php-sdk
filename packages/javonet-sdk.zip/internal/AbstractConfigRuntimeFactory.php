<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\RuntimeContext;

interface AbstractConfigRuntimeFactory
{
    public function clr(string $configName): RuntimeContext;
    public function jvm(string $configName): RuntimeContext;
    public function netcore(string $configName): RuntimeContext;
    public function perl(string $configName): RuntimeContext;
    public function python(string $configName): RuntimeContext;
    public function ruby(string $configName): RuntimeContext;
    public function nodejs(string $configName): RuntimeContext;
    public function python27(string $configName): RuntimeContext;
    public function php(string $configName): RuntimeContext;
}