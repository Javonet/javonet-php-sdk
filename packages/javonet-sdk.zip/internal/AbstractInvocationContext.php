<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\InvocationContext;

interface AbstractInvocationContext
{
    public function execute(): InvocationContext;
}
