<?php

declare(strict_types=1);

namespace sdk\tools;

use Exception;
use GuzzleHttp\Promise\{
    Create,
    PromiseInterface
};
use utils\Uri;

final class HttpConnection
{
    private URI $uri;
    private $multiHandle = null;

    public function __construct(URI $uri)
    {
        $this->uri = $uri;
        $this->ensureMultiHandleInitialized();
    }

    public function sendAsync(string $payload): PromiseInterface
    {
        $conn = null;
        try {
            $conn = curl_init($this->uri->toString());
            curl_setopt_array($conn, [
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_POST => true,
//                CURLOPT_SSL_VERIFYPEER => false,
                CURLOPT_HTTPHEADER => [
                    'Content-Type: application/json',
                    'Accept: application/json'
                ],
                CURLOPT_POSTFIELDS => unpack('C*', mb_convert_encoding($payload, 'UTF-8')),
                CURLOPT_TIMEOUT => 30,
            ]);

            curl_multi_add_handle($this->multiHandle, $conn);

            return $this->createAsyncPromise($conn);
        } catch (Exception $e) {
            if ($conn !== null) {
                curl_close($conn);
            }
            return Create::rejectionFor(-1);
        }
    }

    private function createAsyncPromise($curlHandle): PromiseInterface
    {
        try {
            $result = $this->waitForAsyncRequest($curlHandle);
            return Create::promiseFor($result);
        } catch (Exception $e) {
            return Create::rejectionFor(-1);
        }
    }

    private function waitForAsyncRequest($curlHandle): int
    {
        do {
            $status = curl_multi_exec($this->multiHandle, $active);
            if ($status !== CURLM_OK) {
                throw new Exception('curl_multi_exec failed: ' . curl_multi_strerror($status));
            }
            while ($info = curl_multi_info_read($this->multiHandle)) {
                $handle = $info['handle'];
                if ($handle === $curlHandle) {
                    if ($info['result'] === CURLE_OK) {
                        $httpCode = curl_getinfo($curlHandle, CURLINFO_HTTP_CODE);
                        curl_multi_remove_handle($this->multiHandle, $curlHandle);
                        curl_close($curlHandle);

                        return $httpCode;
                    } else {
                        curl_multi_remove_handle($this->multiHandle, $curlHandle);
                        curl_close($curlHandle);

                        return -1;
                    }
                } else {
                    curl_multi_remove_handle($this->multiHandle, $handle);
                    curl_close($handle);
                }
            }

            if ($active > 0) {
                if (curl_multi_select($this->multiHandle, 0.01) === -1) {
                    throw new Exception(curl_multi_strerror(curl_multi_errno($this->multiHandle)));
                }
            }
        } while ($active > 0);
        
        return -1;
    }
    private function ensureMultiHandleInitialized(): void
    {
        if ($this->multiHandle === null) {
            $this->multiHandle = curl_multi_init();
        }
    }
}
