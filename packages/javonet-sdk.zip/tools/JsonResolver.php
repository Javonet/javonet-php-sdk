<?php

declare(strict_types=1);

namespace sdk\tools;

use Exception;
use InvalidArgumentException;
use stdClass;

final class JsonResolver
{
    private string $configSource;
    private stdClass $jsonObject;

    /** @var stdClass | array $runtimes*/
    private $runtimes;

    public function __construct(string $configSource)
    {
        $this->configSource = $configSource;

        $jsonText = $configSource;
        if (file_exists($configSource)) {
            $content = @file_get_contents($configSource);
            if ($content === false) {
                throw new InvalidArgumentException(
                    sprintf('Unable to read configuration file: %s',
                        $this->configSource)
                );
            }
            $jsonText = $content;
        }

        $decodedJson = json_decode($jsonText);
        if (json_last_error() !== JSON_ERROR_NONE) {
            throw new InvalidArgumentException(
                sprintf(
                    'Configuration source is not a valid JSON. Check your configuration: %s (Error: %s)',
                    $this->configSource,
                    json_last_error_msg()
                )
            );
        }

        if (!$decodedJson instanceof \stdClass) {
            throw new InvalidArgumentException(
                'Expected top-level JSON object, received: ' . gettype($decodedJson)
            );
        }

        $this->jsonObject = $decodedJson;
    }

    public function getLicenseKey(): string
    {
        try {
            return (string) $this->jsonObject->licenseKey;
        } catch (Exception $e) {
            throw new InvalidArgumentException('License key not found in configuration source. Check your configuration source.');
        }
    }

    public function getWorkingDirectory(): string
    {
        try {
            return $this->jsonObject->workingDirectory;
        } catch (Exception $e) {
            throw new InvalidArgumentException('Working directory not found in configuration source. Check your configuration source.');
        }
    }

    private function loadRuntimes(): void
    {
        $this->runtimes = $this->jsonObject->runtimes;
    }

    private function getRuntime(string $runtimeName, string $configName): stdClass
    {
        $this->loadRuntimes();
        $runtime = $this->runtimes->$runtimeName;

        if (is_array($runtime)) {
            foreach ($runtime as $item) {
                if ($item instanceof stdClass && property_exists($item, 'name') && (string) $item->name === $configName) {
                    return $item;
                }
            }
        } elseif ($runtime instanceof stdClass) {
            if (property_exists($runtime, 'name') && (string) $runtime->name === $configName) {
                return $runtime;
            }
        }

        throw new InvalidArgumentException(
            sprintf('Runtime config %s not found in configuration source for runtime %s. Check your configuration source.',
            $configName,
            $runtimeName)
        );
    }

    private function getRuntimeName(string $runtimeName, string $configName): string
    {
        $runtime = $this->getRuntime($runtimeName, $configName);
        return $runtime->name;
    }

    private function getChannel(string $runtimeName, string $configName): stdClass
    {
        $runtime = $this->getRuntime($runtimeName, $configName);
        return $runtime->channel;
    }

    public function getChannelType(string $runtimeName, string $configName): string
    {
        $channel = $this->getChannel($runtimeName, $configName);
        return $channel->type;
    }

    public function getChannelHost(string $runtimeName, string $configName): string
    {
        $channel = $this->getChannel($runtimeName, $configName);
        return $channel->host;
    }

    public function getChannelPort(string $runtimeName, string $configName): int
    {
        $channel = $this->getChannel($runtimeName, $configName);
        return $channel->port;
    }

    public function getModules(string $runtimeName, string $configName): string
    {
        $runtime = $this->getRuntime($runtimeName, $configName);
        if (property_exists($runtime, 'modules')) {
            return $runtime->modules;
        }

        return '';
    }
}
