<?php

declare(strict_types=1);

namespace sdk;

use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\TcpConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\UtilsConst;

final class Javonet
{
    private function __construct()
    {
    }

    public static function inMemory(): RuntimeFactory
    {
        return new RuntimeFactory(new InMemoryConnectionData());
    }

    public static function tcp(TcpConnectionData $connectionData): RuntimeFactory
    {
        return new RuntimeFactory($connectionData);
    }

    public static function webSocket(WsConnectionData $connectionData): RuntimeFactory
    {
        return new RuntimeFactory($connectionData);
    }

    public static function withConfig(string $configSource): ConfigRuntimeFactory
    {
        return new ConfigRuntimeFactory($configSource);
    }

    public static function activate(string $licenseKey): void
    {
        UtilsConst::setLicenseKey($licenseKey);
    }

    public static function setConfigSource(string $configSource): void
    {
        UtilsConst::setConfigSource($configSource);
    }

    public static function setJavonetWorkingDirectory(string $path): void
    {
        UtilsConst::setJavonetWorkingDirectory($path);
    }
}
