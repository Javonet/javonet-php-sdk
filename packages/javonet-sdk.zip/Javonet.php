<?php

declare(strict_types=1);

namespace sdk;

use sdk\configuration\ConfigPriority;
use sdk\configuration\ConfigSourceResolver;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\TcpConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\UtilsConst;

final class Javonet
{
    private function __construct()
    {}

    public static function inMemory(): RuntimeFactory
    {
        return new RuntimeFactory(new InMemoryConnectionData());
    }

    public static function tcp(TcpConnectionData $IConnectionData): RuntimeFactory
    {
        return new RuntimeFactory($IConnectionData);
    }

    public static function webSocket(WsConnectionData $IConnectionData): RuntimeFactory
    {
        return new RuntimeFactory($IConnectionData);
    }

    public static function withConfig(string $configSource): ConfigRuntimeFactory
    {
        return new ConfigRuntimeFactory($configSource);
    }

    public static function activate(string $licenseKey): void
    {
        UtilsConst::setLicenseKey($licenseKey);
    }

    public static function setConfigSource(string $configSource): void
    {
        UtilsConst::setConfigSource($configSource);
    }

    public static function setJavonetWorkingDirectory(string $path): void
    {
        UtilsConst::setJavonetWorkingDirectory($path);
    }

    public static function addConfig(ConfigPriority $configPriority, string $configSource): void
    {
        ConfigSourceResolver::addConfigs($configPriority, $configSource);
    }

    public static function initializeRC(string $configName) : RuntimeContext
    {
        return RuntimeContext::initializeRuntimeContext(ConfigSourceResolver::getConfig($configName));
    }
}
