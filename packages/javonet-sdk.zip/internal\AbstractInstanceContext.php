<?php

declare(strict_types=1);

namespace sdk\internal;

use Sdk\InvocationContext;

interface AbstractInstanceContext
{
    public function getInstanceField(string $fieldName): InvocationContext;
    public function setInstanceField(string $fieldName, $value): InvocationContext;
    public function invokeInstanceMethod(string $methodName, ...$args): InvocationContext;
    public function createInstance(...$args): InvocationContext;
    public function invokeGenericMethod(string $methodName, ...$args): InvocationContext;
    public function getRefValue(): InvocationContext;
    public function createNull(): InvocationContext;
    public function getInstanceMethodAsDelegate(string $methodName, ...$args): InvocationContext;
}