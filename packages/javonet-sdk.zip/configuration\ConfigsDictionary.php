<?php

namespace sdk\configuration;

use InvalidArgumentException;

class ConfigsDictionary
{
    /**
     * @var array<string, array<string, Config>>
     */
    private static array $configurationsCollection = [];

    /**
     * @var array<int>|null
     */
    private static ?array $prioritiesInOrder = null;

    public static function addConfig(string $name, ConfigPriority $priority, Config $config): void
    {
        if (empty(trim($name))) {
            echo "Config name cannot be null or whitespace. Skipping add.\n";
            return;
        }

        if ($config === null) {
            echo "Config instance is null. Skipping add.\n";
            return;
        }

        // Atomically get or create the per-name array
        if (!isset(self::$configurationsCollection[$name])) {
            self::$configurationsCollection[$name] = [];
        }

        // Normalize priority to string key
        $priorityKey = is_int($priority) || is_string($priority)
            ? (string)$priority
            : ConfigPriority::toString($priority);

        // Check if priority already exists
        if (isset(self::$configurationsCollection[$name][$priorityKey])) {
            echo "Config with name '$name' and priority '" . ConfigPriority::toString($priority) . "' already exists. Skipping.\n";
            return;
        }

        // Add the config using normalized key
        self::$configurationsCollection[$name][$priorityKey] = $config;

        echo "Added configuration '$name' with priority '" . ConfigPriority::toString($priority) . "' and parameters $config\n";
    }

    public static function getConfig(string $name): Config
    {
        if (empty(trim($name))) {
            throw new InvalidArgumentException("Config name cannot be null or whitespace");
        }

        if (!isset(self::$configurationsCollection[$name]) ||
            empty(self::$configurationsCollection[$name])) {
            throw new InvalidArgumentException("Configuration $name not found");
        }

        $perPriority = self::$configurationsCollection[$name];

        // Probe priorities in ascending order (lower = higher priority)
        foreach (self::getPrioritiesInOrder() as $priority) {
            $priorityKey = is_int($priority) || is_string($priority)
                ? (string)$priority
                : ConfigPriority::toString($priority);

            if (isset($perPriority[$priorityKey])) {
                $cfg = $perPriority[$priorityKey];
                echo "Retrieved configuration `$name` with priority `" . ConfigPriority::toString($priority) . "` and parameters $cfg\n";
                return $cfg;
            }
        }

        throw new InvalidArgumentException("Configuration $name not found");
    }

    public static function clearConfigs(): void
    {
        self::$configurationsCollection = [];
    }

    /**
     * @return array<int>
     */
    private static function getPrioritiesInOrder(): array
    {
        if (self::$prioritiesInOrder === null) {
            self::$prioritiesInOrder = ConfigPriority::getAllPriorities();
        }
        return self::$prioritiesInOrder;
    }
}
