<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\InvocationContext;

interface AbstractEventContext
{
    public function addEventListener(string $eventName, $eventHandler): InvocationContext;
}