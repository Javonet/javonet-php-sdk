<?php

declare(strict_types=1);

namespace sdk;

use sdk\internal\AbstractRuntimeFactory;
use utils\connectiondata\IConnectionData;
use utils\RuntimeName;

final class RuntimeFactory implements AbstractRuntimeFactory
{
    private IConnectionData $connectionData;

    public function __construct(
        IConnectionData $connectionData
    ) {
        $this->connectionData = $connectionData;
    }

    public function clr(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::CLR(), $this->connectionData);
    }

    public function jvm(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::JVM(), $this->connectionData);
    }

    public function netcore(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::NETCORE(), $this->connectionData);
    }

    public function perl(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::PERL(), $this->connectionData);
    }

    public function python(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::PYTHON(), $this->connectionData);
    }

    public function ruby(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::RUBY(), $this->connectionData);
    }

    public function nodejs(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::NODEJS(), $this->connectionData);
    }

    public function python27(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::PYTHON27(), $this->connectionData);
    }

    public function php(): RuntimeContext
    {
        return RuntimeContext::getInstance(RuntimeName::PHP(), $this->connectionData);
    }
}
