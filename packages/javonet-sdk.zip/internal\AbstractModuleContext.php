<?php

declare(strict_types=1);

namespace sdk\internal;

use sdk\RuntimeContext;

interface AbstractModuleContext
{
    public function loadLibrary(string $libraryPath): RuntimeContext;
}