<?php

namespace sdk\configuration;

use utils\connectiondata\IConnectionData;
use utils\RuntimeName;

class Config
{
    private RuntimeName $runtime;
    private ?IConnectionData $IConnectionData;
    private string $modules;
    private string $plugins;
    private ?IConnectionData $connectionData;

    public function __construct(
        RuntimeName $runtime,
        ?IConnectionData $IConnectionData = null,
        string $plugins = "",
        string $modules = ""
    ) {
        $this->runtime = $runtime;
        $this->connectionData = $IConnectionData;
        $this->plugins = $plugins;
        $this->modules = $modules;
    }

    public function getRuntime(): RuntimeName
    {
        return $this->runtime;
    }

    public function setRuntime(RuntimeName $runtime): void
    {
        $this->runtime = $runtime;
    }

    public function getConnectionData(): ?IConnectionData
    {
        return $this->connectionData;
    }

    public function setConnectionData(?IConnectionData $connectionData): void
    {
        $this->connectionData = $connectionData;
    }

    public function getModules(): string
    {
        return $this->modules;
    }

    public function setModules(string $modules): void
    {
        $this->modules = $modules;
    }

    public function __toString(): string
    {
        $parts = [];
        $parts[] = "Runtime: " . $this->runtime;

        if ($this->connectionData !== null &&
            !empty(trim($this->connectionData->getHostname()))) {
            $parts[] = "Host: " . $this->connectionData;
        }

        if (!empty(trim($this->plugins))) {
            $parts[] = "Plugins: " . $this->plugins;
        }

        if (!empty(trim($this->modules))) {
            $parts[] = "Modules: " . $this->modules;
        }

        return implode(", ", $parts);
    }
}
