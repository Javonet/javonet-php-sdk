<?php

namespace sdk\configuration;

use sdk\configuration\configresolvers\JsonConfigResolver;
use sdk\configuration\configresolvers\YamlConfigResolver;
use sdk\configuration\configresolvers\ConnectionStringConfigResolver;
use InvalidArgumentException;
use JsonException;

class ConfigSourceResolver
{
    public static function addConfigs(ConfigPriority $priority, string $configSource): void
    {
        echo "Adding config from source: $configSource with priority '" . ConfigPriority::toString($priority) . "'\n";
        $configString = self::getConfigSourceAsString($configSource);
        self::parseConfigsAndAddToCollection($priority, $configString);
    }

    public static function getConfig(string $configName): Config
    {
        echo "Retrieving config $configName\n";
        return ConfigsDictionary::getConfig($configName);
    }

    public static function clearConfigs(): void
    {
        ConfigsDictionary::clearConfigs();
    }

    private static function getConfigSourceAsString(string $configSource): string
    {
        // check if configSource is null or whitespace
        if (empty(trim($configSource))) {
            throw new InvalidArgumentException("Config source cannot be null or whitespace.");
        }

        // check if configSource is an environment variable
        $envValue = getenv($configSource);
        if ($envValue !== false && !empty(trim($envValue))) {
            // if env variable exists, use its value as configSource
            $configSource = $envValue;
        }

        // check if configSource is a path to a file
        if (file_exists($configSource)) {
            // if file exists, read its content as configSource
            $content = file_get_contents($configSource);
            if ($content === false) {
                throw new InvalidArgumentException("Failed to read file: $configSource");
            }
            $configSource = $content;
        }

        // return configSource as is
        return trim($configSource);
    }

    private static function parseConfigsAndAddToCollection(ConfigPriority $priority, string $configString): void
    {
        // Try JSON first
        try {
            $jsonObject = json_decode($configString, true, 512, JSON_THROW_ON_ERROR);
            JsonConfigResolver::addConfigs($priority, $jsonObject);
            return;
        } catch (JsonException $e) {
            // Not JSON – continue to YAML attempt
        } catch (\Exception $ex) {
            throw new InvalidArgumentException("Failed to parse config source as JSON: " . $ex->getMessage(), 0, $ex);
        }

        // Try YAML
        try {
            YamlConfigResolver::addConfigs($priority, $configString);
            return;
        } catch (\InvalidArgumentException $ex) {
            // fallback to connection string
        } catch (\Exception $ex) {
            throw new InvalidArgumentException("Failed to parse config source as YAML: " . $ex->getMessage(), 0, $ex);
        }

        // Try connection string
        try {
            ConnectionStringConfigResolver::addConfigs($priority, $configString);
            return;
        } catch (\Exception $ex) {
            echo "Failed to parse config source as connection string: " . $ex->getMessage() . "\n";
        }

        throw new InvalidArgumentException("Config source is not valid JSON, YAML, or connection string format:\n" . $configString."\n");
    }
}
