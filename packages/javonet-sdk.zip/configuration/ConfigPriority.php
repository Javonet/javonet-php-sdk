<?php
declare(strict_types=1);

namespace sdk\configuration;

use InvalidArgumentException;
use utils\Enum;

final class ConfigPriority extends Enum
{
    public const RuntimeSpecificEnv = 0;
    public const GlobalEnv = 1;
    public const RuntimeSpecificFile = 2;
    public const GlobalFile = 3;
    public const User = 4;
    public const DefaultLibrary = 5;

    public static function toString(ConfigPriority $priority): string
    {
        switch ($priority->getValue()) {
            case self::RuntimeSpecificEnv:
                return 'RuntimeSpecificEnv';
            case self::GlobalEnv:
                return 'GlobalEnv';
            case self::RuntimeSpecificFile:
                return 'RuntimeSpecificFile';
            case self::GlobalFile:
                return 'GlobalFile';
            case self::User:
                return 'User';
            case self::DefaultLibrary:
                return 'DefaultLibrary';
            default:
                throw new InvalidArgumentException('Invalid ConfigPriority value');
        }
    }

    public static function getAllPriorities() : array
    {
        return [
            new ConfigPriority(self::RuntimeSpecificEnv),
            new ConfigPriority(self::GlobalEnv),
            new ConfigPriority(self::RuntimeSpecificFile),
            new ConfigPriority(self::GlobalFile),
            new ConfigPriority(self::User),
            new ConfigPriority(self::DefaultLibrary),
        ];
    }
}
