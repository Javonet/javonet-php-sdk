<?php

namespace sdk\configuration\configresolvers;

use Exception;
use InvalidArgumentException;
use utils\RuntimeName;
use utils\RuntimeNameHandler;
use utils\connectiondata\IConnectionData;
use utils\connectiondata\InMemoryConnectionData;
use utils\connectiondata\WsConnectionData;
use utils\connectiondata\TcpConnectionData;

abstract class ConfigResolver
{
    protected static function tryParseRuntime(string $runtime): RuntimeName
    {
        $runtime = trim($runtime);
        if (empty($runtime)) {
            throw new InvalidArgumentException('Runtime string cannot be null or whitespace.');
        }
        return RuntimeNameHandler::getRuntimeName($runtime);
    }

    protected static function buildConnectionData(?string $hostValue): IConnectionData
    {
        $hostValue = trim($hostValue);
        if (empty($hostValue)) {
            return new InMemoryConnectionData();
        }

        $lowerHostValue = strtolower($hostValue);

        if ($lowerHostValue === 'inmemory' || $lowerHostValue === 'in-memory') {
            return new InMemoryConnectionData();
        }

        if (strpos($lowerHostValue, 'ws://') === 0 || strpos($lowerHostValue, 'wss://') === 0) {
            return new WsConnectionData($hostValue);
        }

        if (strpos($lowerHostValue, 'tcp://') === 0) {
            try {
                return self::parseTcp(substr($hostValue, 6));
            } catch (Exception $e) {
                return new InMemoryConnectionData();
            }
        }

        // host:port
        $colon = strpos($hostValue, ':');
        if ($colon > 0 && $colon < strlen($hostValue) - 1) {
            $portPart = substr($hostValue, $colon + 1);
            $slash = strpos($portPart, '/');
            if ($slash !== false) {
                $portPart = substr($portPart, 0, $slash);
            }
            $port = filter_var($portPart, FILTER_VALIDATE_INT);
            if ($port !== false) {
                $hostOnly = substr($hostValue, 0, $colon);
                if (!empty(trim($hostOnly))) {
                    try {
                        return new TcpConnectionData($hostOnly, $port);
                    } catch (Exception $e) {
                        return new InMemoryConnectionData();
                    }
                }
            }
        }

        // Fallback to InMemory
        return new InMemoryConnectionData();
    }

    protected static function parseTcp(string $address): IConnectionData
    {
        $slash = strpos($address, '/');
        $hostPort = $slash !== false ? substr($address, 0, $slash) : $address;
        $colon = strrpos($hostPort, ':');

        if ($colon === false || $colon <= 0 || $colon >= strlen($hostPort) - 1) {
            throw new InvalidArgumentException('Invalid tcp:// format.');
        }

        $host = substr($hostPort, 0, $colon);
        $portStr = substr($hostPort, $colon + 1);
        $port = filter_var($portStr, FILTER_VALIDATE_INT);

        if ($port === false) {
            throw new InvalidArgumentException('Invalid port in tcp:// address.');
        }

        return new TcpConnectionData($host, $port);
    }
}
