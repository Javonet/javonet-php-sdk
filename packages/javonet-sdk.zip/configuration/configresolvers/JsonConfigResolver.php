<?php

namespace sdk\configuration\configresolvers;

use InvalidArgumentException;
use sdk\configuration\Config;
use sdk\configuration\ConfigPriority;
use sdk\configuration\ConfigsDictionary;
use utils\UtilsConst;

class JsonConfigResolver extends ConfigResolver
{
    /**
     * Reads all configs from JSON and adds them under given priority.
     * @param ConfigPriority $priority
     * @param array $jsonObject Decoded JSON as associative array
     */
    public static function addConfigs(ConfigPriority $priority, array $jsonObject): void
    {
        if (empty($jsonObject)) {
            throw new InvalidArgumentException('Root JSON element must be an object.');
        }

        // Handle license key
        if (isset($jsonObject['licenseKey']) && is_string($jsonObject['licenseKey'])) {
            UtilsConst::setLicenseKey(trim($jsonObject['licenseKey']));
        }

        // Get configurations
        if (!isset($jsonObject['configurations']) || !is_array($jsonObject['configurations'])) {
            throw new InvalidArgumentException("JSON must contain 'configurations' object.");
        }

        $configurations = $jsonObject['configurations'];

        foreach ($configurations as $configName => $cfg) {
            try {
                if (!is_array($cfg)) {
                    throw new InvalidArgumentException("Configuration value must be an object.");
                }

                $runtimeName = self::tryParseRuntime(self::getRequiredString($cfg, 'runtime'));

                $host = self::getOptionalString($cfg, 'host');
                $IConnectionData = self::buildConnectionData($host);

                $plugins = self::getOptionalString($cfg, 'plugins');
                $modules = self::getOptionalString($cfg, 'modules');

                $config = new Config($runtimeName, $IConnectionData, $plugins, $modules);
                ConfigsDictionary::addConfig($configName, $priority, $config);
            } catch (\Exception $ex) {
                echo "Failed to add config '$configName': " . $ex->getMessage() . "\n";
            }
        }
    }

    private static function getRequiredString(array $obj, string $property): string
    {
        if (!isset($obj[$property]) || !is_string($obj[$property])) {
            throw new InvalidArgumentException("Missing or invalid '$property' property.");
        }

        $value = trim($obj[$property]);
        if (empty($value)) {
            throw new InvalidArgumentException("Property '$property' cannot be empty.");
        }

        return $value;
    }

    private static function getOptionalString(array $obj, string $property): string
    {
        if (isset($obj[$property]) && is_string($obj[$property])) {
            return $obj[$property];
        }
        return '';
    }
}
