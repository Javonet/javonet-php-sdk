<?php

namespace sdk\configuration\configresolvers;

use InvalidArgumentException;
use sdk\configuration\Config;
use sdk\configuration\ConfigPriority;
use sdk\configuration\ConfigsDictionary;
use Symfony\Component\Yaml\Exception\ParseException;
use Symfony\Component\Yaml\Yaml;
use utils\UtilsConst;

class YamlConfigResolver extends ConfigResolver
{
    /**
     * Reads all configs from YAML string and adds them under given priority.
     * Requires symfony/yaml package (composer require symfony/yaml)
     * @param ConfigPriority $priority
     * @param string $yamlString
     */
    public static function addConfigs(ConfigPriority $priority, string $yamlString): void
    {
        if (empty(trim($yamlString))) {
            throw new InvalidArgumentException("YAML string cannot be null or empty.");
        }

        try {
            $data = Yaml::parse($yamlString);
        } catch (ParseException $ex) {
            throw new InvalidArgumentException("Failed to parse YAML: " . $ex->getMessage(), 0, $ex);
        }

        if (!is_array($data)) {
            throw new InvalidArgumentException("Root YAML node must be a mapping (object).");
        }

        // Handle license key
        if (isset($data['licenseKey']) && is_string($data['licenseKey'])) {
            UtilsConst::setLicenseKey(trim($data['licenseKey']));
        }

        // Get configurations
        if (!isset($data['configurations']) || !is_array($data['configurations'])) {
            throw new InvalidArgumentException("YAML must contain 'configurations' mapping.");
        }

        $configurations = $data['configurations'];

        foreach ($configurations as $configName => $cfg) {
            if (!is_string($configName) || empty(trim($configName))) {
                echo "Skipping entry with empty config name.\n";
                continue;
            }

            if (!is_array($cfg)) {
                echo "Skipping '$configName': value is not a mapping.\n";
                continue;
            }

            try {
                $runtimeValue = self::getRequiredString($cfg, 'runtime');
                $runtimeName = self::tryParseRuntime($runtimeValue);

                $host = self::getOptionalString($cfg, 'host');
                $IConnectionData = self::buildConnectionData($host);

                $plugins = self::getOptionalString($cfg, 'plugins');
                $modules = self::getOptionalString($cfg, 'modules');

                $config = new Config($runtimeName, $IConnectionData, $plugins, $modules);
                ConfigsDictionary::addConfig($configName, $priority, $config);
            } catch (\Exception $ex) {
                echo "Failed to add config '$configName': " . $ex->getMessage() . "\n";
            }
        }
    }

    private static function getRequiredString(array $mapping, string $key): string
    {
        if (!isset($mapping[$key]) || !is_string($mapping[$key]) || empty(trim($mapping[$key]))) {
            throw new InvalidArgumentException("Missing or invalid '$key' property.");
        }
        return trim($mapping[$key]);
    }

    private static function getOptionalString(array $mapping, string $key): string
    {
        if (isset($mapping[$key]) && is_string($mapping[$key])) {
            return $mapping[$key];
        }
        return '';
    }
}
